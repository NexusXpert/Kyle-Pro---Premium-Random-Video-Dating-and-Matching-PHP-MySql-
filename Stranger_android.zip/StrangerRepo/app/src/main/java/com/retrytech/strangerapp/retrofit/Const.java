package com.retrytech.strangerapp.retrofit;

import androidx.annotation.Keep;

import com.retrytech.strangerapp.BuildConfig;


@Keep
public final class Const {
    public static final String BASE_URL = "http://--------/api/";
    public static final String ITEM_URL = "http://--------/public/storage/";
    public static final String PRIVACY_POLICY = "--------";
    public static final String TERMS_OF_USE = "--------";
    public static final String AGORA_APP_ID = "-----------------";
    public static final String AGORA_APP_CERTIFICATE = "-----------------";
    public static final String API_KEY = "----";
    public static final String USER = "user";
    public static final String PREF_NAME = BuildConfig.APPLICATION_ID;
    public static final String CURRENCY = "$";
    public static final String FAKE_USER = "fake_user";

    public static String Settings = "settings";
    public static String FREE_COINS_ADDED = "free_coins_added";


}

