package com.retrytech.strangerapp.utils.media;

public interface PackableEx extends Packable {
    void unmarshal(ByteBuf in);
}
