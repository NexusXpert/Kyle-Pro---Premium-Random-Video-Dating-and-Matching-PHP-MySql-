package com.retrytech.strangerapp.activity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.databinding.DataBindingUtil;

import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.retrytech.strangerapp.R;
import com.retrytech.strangerapp.databinding.ActivityFakeVideoBinding;
import com.retrytech.strangerapp.modal.fakeuser.FakeUser;
import com.retrytech.strangerapp.retrofit.Const;
import com.retrytech.strangerapp.utils.SessionManager;

import java.util.Random;

public class FakeVideoActivity extends AppCompatActivity {

    ActivityFakeVideoBinding binding;
    SimpleExoPlayer player;
    private boolean mMuted = false;
    private boolean isFrontCamera = true;
    String videoUrl = "";
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        decorView.setOnApplyWindowInsetsListener((v, insets) -> {
            WindowInsets defaultInsets = v.onApplyWindowInsets(insets);
            return defaultInsets.replaceSystemWindowInsets(
                    defaultInsets.getSystemWindowInsetLeft(),
                    0,
                    defaultInsets.getSystemWindowInsetRight(),
                    defaultInsets.getSystemWindowInsetBottom());
        });
        ViewCompat.requestApplyInsets(decorView);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, android.R.color.transparent));

        binding = DataBindingUtil.setContentView(this, R.layout.activity_fake_video);
        sessionManager = new SessionManager(this);
        FakeUser fakeUser = sessionManager.getFakeUser();
        if (fakeUser != null && !fakeUser.getData().isEmpty()) {
            int random = new Random().nextInt((fakeUser.getData().size()));
            videoUrl = Const.ITEM_URL + fakeUser.getData().get(random).getVideo();
            binding.tvUserName.setText(fakeUser.getData().get(random).getFullname());
            binding.tvUserLocation.setText(fakeUser.getData().get(random).getLocation());
            Glide.with(this).load(Const.ITEM_URL + fakeUser.getData().get(random).getImage()).circleCrop().into(binding.imgUser);

            fakeUser.getData().remove(random);
            sessionManager.saveFakeUsers(fakeUser);
        }
        setVideo();

    }

    private void setVideo() {
        player = new SimpleExoPlayer.Builder(this).build();
        binding.playerview.setPlayer(player);
        binding.playerview.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        Uri uri = Uri.parse(videoUrl);
        com.google.android.exoplayer2.upstream.DataSource.Factory dataSourceFactory =
                new DefaultDataSourceFactory(this, "exoplayer-retrytech");
        MediaSource mediaSource = new ProgressiveMediaSource.Factory(dataSourceFactory)
                .createMediaSource(uri);
        Log.d("TAG", "initializePlayer: " + uri);
        player.setPlayWhenReady(true);
        player.prepare(mediaSource, false, false);
        initCamera();
    }

    private void initCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA},
                    1);
        } else {
            binding.surfaceCamera.bindToLifecycle(this);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        initCamera();
    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        player.release();
    }

    public void onLocalAudioMuteClicked(View view) {
        Log.d("TAG", "onLocalAudioMuteClicked: " + view);

        mMuted = !mMuted;
        int res = mMuted ? R.drawable.btn_mute : R.drawable.btn_unmute;
        binding.btnMute.setImageResource(res);
    }

    @Override
    protected void onPause() {
        super.onPause();
        player.setVolume(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        player.setVolume(1);
    }

    public void onSwitchCameraClicked(View view) {
        isFrontCamera = !isFrontCamera;
        binding.surfaceCamera.toggleCamera();
    }

    public void onCallClicked(View view) {
        onBackPressed();
    }
}