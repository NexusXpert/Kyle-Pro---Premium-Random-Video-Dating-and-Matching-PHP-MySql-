package com.retrytech.strangerapp.modal;

import com.google.gson.annotations.SerializedName;

public class User {

    @SerializedName("new_user")
    private boolean newUser;

    @SerializedName("data")
    private Data data;

    @SerializedName("message")
    private String message;

    @SerializedName("status")
    private boolean status;

    public boolean isNewUser() {
        return newUser;
    }

    public void setNewUser(boolean newUser) {
        this.newUser = newUser;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public static class Data {

        @SerializedName("location")
        private String location;
        @SerializedName("blocked_users")
        private String blockedUsers;
        @SerializedName("image")
        private String image;
        @SerializedName("fullname")
        private String fullname;
        @SerializedName("updated_at")
        private String updatedAt;
        @SerializedName("identity")
        private String identity;
        @SerializedName("created_at")
        private String createdAt;
        @SerializedName("id")
        private int id;
        @SerializedName("is_search")
        private int isSearch;
        @SerializedName("token")
        private String token;
        @SerializedName("video")
        private String video;
        @SerializedName("gender")
        private int gender = -1;
        @SerializedName("is_fack")
        private int is_fake;
        @SerializedName("is_block")
        private int is_block;
        @SerializedName("coin")
        private int coins;


        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(String updatedAt) {
            this.updatedAt = updatedAt;
        }

        public String getIdentity() {
            return identity;
        }

        public void setIdentity(String identity) {
            this.identity = identity;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getIsSearch() {
            return isSearch;
        }

        public void setIsSearch(int isSearch) {
            this.isSearch = isSearch;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public int getGender() {
            return gender;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public int getIs_fake() {
            return is_fake;
        }

        public void setIs_fake(int is_fake) {
            this.is_fake = is_fake;
        }

        public int getIs_block() {
            return is_block;
        }

        public void setIs_block(int is_block) {
            this.is_block = is_block;
        }

        public int getCoins() {
            return coins;
        }

        public void setCoins(int coins) {
            this.coins = coins;
        }

        public String getVideo() {
            return video;
        }

        public void setVideo(String video) {
            this.video = video;
        }

        public String getFullname() {
            return fullname;
        }

        public void setFullname(String fullname) {
            this.fullname = fullname;
        }

        public String getBlockedUsers() {
            return blockedUsers;
        }

        public void setBlockedUsers(String blockedUsers) {
            this.blockedUsers = blockedUsers;
        }
    }
}