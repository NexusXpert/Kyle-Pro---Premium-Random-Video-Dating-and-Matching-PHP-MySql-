package com.retrytech.strangerapp.modal.searchuser;

import com.google.gson.annotations.SerializedName;
import com.retrytech.strangerapp.modal.User;

import java.util.List;

public class SearchUser {

    @SerializedName("data")
    private List<User.Data> data;

    @SerializedName("message")
    private String message;

    @SerializedName("status")
    private boolean status;

    public List<User.Data> getData() {
        return data;
    }

    public void setData(List<User.Data> data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public static class DataItem {

        @SerializedName("image")
        private Object image;

        @SerializedName("gender")
        private int gender;

        @SerializedName("is_block")
        private int isBlock;

        @SerializedName("created_at")
        private String createdAt;

        @SerializedName("video")
        private Object video;

        @SerializedName("is_fack")
        private int isFack;

        @SerializedName("token")
        private String token;

        @SerializedName("updated_at")
        private String updatedAt;

        @SerializedName("identity")
        private String identity;

        @SerializedName("location")
        private Object location;

        @SerializedName("id")
        private int id;

        @SerializedName("fullname")
        private String fullname;

        @SerializedName("is_search")
        private int isSearch;

        @SerializedName("coin")
        private int coin;

        public Object getImage() {
            return image;
        }

        public void setImage(Object image) {
            this.image = image;
        }

        public int getGender() {
            return gender;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public int getIsBlock() {
            return isBlock;
        }

        public void setIsBlock(int isBlock) {
            this.isBlock = isBlock;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public Object getVideo() {
            return video;
        }

        public void setVideo(Object video) {
            this.video = video;
        }

        public int getIsFack() {
            return isFack;
        }

        public void setIsFack(int isFack) {
            this.isFack = isFack;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(String updatedAt) {
            this.updatedAt = updatedAt;
        }

        public String getIdentity() {
            return identity;
        }

        public void setIdentity(String identity) {
            this.identity = identity;
        }

        public Object getLocation() {
            return location;
        }

        public void setLocation(Object location) {
            this.location = location;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getFullname() {
            return fullname;
        }

        public void setFullname(String fullname) {
            this.fullname = fullname;
        }

        public int getIsSearch() {
            return isSearch;
        }

        public void setIsSearch(int isSearch) {
            this.isSearch = isSearch;
        }

        public int getCoin() {
            return coin;
        }

        public void setCoin(int coin) {
            this.coin = coin;
        }
    }
}