package com.retrytech.strangerapp.utils.sample;


import com.retrytech.strangerapp.utils.media.RtcTokenBuilder;

public class RtcTokenBuilderSample {

    String appId = "------";
    String appCertificate = "------";
    int expirationTimeInSeconds = 3600;

    public String generateToken(String channelName, int uID) {

        RtcTokenBuilder token = new RtcTokenBuilder();
        int timestamp = (int) (System.currentTimeMillis() / 1000 + expirationTimeInSeconds);
        String result;

        result = token.buildTokenWithUid(appId, appCertificate,
                channelName, uID, RtcTokenBuilder.Role.ROLE_PUBLISHER, timestamp);
        return result;
    }
}
