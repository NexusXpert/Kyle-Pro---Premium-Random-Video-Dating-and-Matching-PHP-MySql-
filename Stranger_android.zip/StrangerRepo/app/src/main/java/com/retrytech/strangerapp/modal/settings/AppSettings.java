package com.retrytech.strangerapp.modal.settings;

import com.google.gson.annotations.SerializedName;

public class AppSettings {

    @SerializedName("gender")
    private Gender gender;

    @SerializedName("miscs")
    private Miscs miscs;

    @SerializedName("message")
    private String message;

    @SerializedName("admobs")
    private Admobs admobs;

    @SerializedName("status")
    private boolean status;

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public Miscs getMiscs() {
        return miscs;
    }

    public void setMiscs(Miscs miscs) {
        this.miscs = miscs;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Admobs getAdmobs() {
        return admobs;
    }

    public void setAdmobs(Admobs admobs) {
        this.admobs = admobs;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public static class Miscs {

        @SerializedName("googleplaylicensekey")
        private String googleplaylicensekey;

        @SerializedName("terms")
        private String terms;

        @SerializedName("id")
        private int id;

        @SerializedName("type")
        private int type;

        @SerializedName("privcy_url")
        private String privcyUrl;

        @SerializedName("more_app")
        private String moreApp;

        public String getGoogleplaylicensekey() {
            return googleplaylicensekey;
        }

        public void setGoogleplaylicensekey(String googleplaylicensekey) {
            this.googleplaylicensekey = googleplaylicensekey;
        }

        public String getTerms() {
            return terms;
        }

        public void setTerms(String terms) {
            this.terms = terms;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public String getPrivcyUrl() {
            return privcyUrl;
        }

        public void setPrivcyUrl(String privcyUrl) {
            this.privcyUrl = privcyUrl;
        }

        public String getMoreApp() {
            return moreApp;
        }

        public void setMoreApp(String moreApp) {
            this.moreApp = moreApp;
        }
    }

    public static class Gender {

        @SerializedName("gendermatch")
        private String gendermatch;

        @SerializedName("defaultcoin")
        private int defaultcoin;

        @SerializedName("id")
        private int id;

        @SerializedName("maxcallduration")
        private String maxcallduration;

        @SerializedName("is_fack")
        private int isFack;

        @SerializedName("facktime")
        private int facktime;

        @SerializedName("rewarded_ads_reward")
        private int rewardedAdsReward;

        @SerializedName("call_price_min")
        private int callPriceMin;

        @SerializedName("bothmatch")
        private String bothMatch;

        public String getGendermatch() {
            return gendermatch;
        }

        public void setGendermatch(String gendermatch) {
            this.gendermatch = gendermatch;
        }

        public int getDefaultcoin() {
            return defaultcoin;
        }

        public void setDefaultcoin(int defaultcoin) {
            this.defaultcoin = defaultcoin;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getMaxcallduration() {
            return maxcallduration;
        }

        public void setMaxcallduration(String maxcallduration) {
            this.maxcallduration = maxcallduration;
        }

        public int getIsFack() {
            return isFack;
        }

        public void setIsFack(int isFack) {
            this.isFack = isFack;
        }

        public int getFacktime() {
            return facktime;
        }

        public void setFacktime(int facktime) {
            this.facktime = facktime;
        }

        public String getBothMatch() {
            return bothMatch;
        }

        public void setBothMatch(String bothMatch) {
            this.bothMatch = bothMatch;
        }

        public int getRewardedAdsReward() {
            return rewardedAdsReward;
        }

        public void setRewardedAdsReward(int rewardedAdsReward) {
            this.rewardedAdsReward = rewardedAdsReward;
        }

        public int getCallPriceMin() {
            return callPriceMin;
        }

        public void setCallPriceMin(int callPriceMin) {
            this.callPriceMin = callPriceMin;
        }
    }

    public static class Admobs {

        @SerializedName("publisher_id")
        private String publisherId;

        @SerializedName("rewarded_id")
        private String rewardedId;

        @SerializedName("native_id")
        private String nativeId;

        @SerializedName("admob_app_id")
        private String admobAppId;

        @SerializedName("banner_id")
        private String bannerId;

        @SerializedName("id")
        private int id;

        @SerializedName("intersial_id")
        private String intersialId;

        @SerializedName("type")
        private int type;

        public String getPublisherId() {
            return publisherId;
        }

        public void setPublisherId(String publisherId) {
            this.publisherId = publisherId;
        }

        public String getRewardedId() {
            return rewardedId;
        }

        public void setRewardedId(String rewardedId) {
            this.rewardedId = rewardedId;
        }

        public String getNativeId() {
            return nativeId;
        }

        public void setNativeId(String nativeId) {
            this.nativeId = nativeId;
        }

        public String getAdmobAppId() {
            return admobAppId;
        }

        public void setAdmobAppId(String admobAppId) {
            this.admobAppId = admobAppId;
        }

        public String getBannerId() {
            return bannerId;
        }

        public void setBannerId(String bannerId) {
            this.bannerId = bannerId;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getIntersialId() {
            return intersialId;
        }

        public void setIntersialId(String intersialId) {
            this.intersialId = intersialId;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }
    }
}