package com.retrytech.strangerapp.modal.coinpackage;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CoinPackages {

    @SerializedName("data")
    private List<Data> data;

    @SerializedName("message")
    private String message;

    @SerializedName("status")
    private boolean status;

    public List<Data> getData() {
        return data;
    }

    public void setData(List<Data> data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public static class Data {

        @SerializedName("playid")
        private String playid;

        @SerializedName("amount")
        private String amount;

        @SerializedName("price")
        private String price;

        @SerializedName("appid")
        private String appid;

        @SerializedName("description")
        private String description;

        @SerializedName("id")
        private int id;

        @SerializedName("title")
        private String title;

        public String getPlayid() {
            return playid;
        }

        public void setPlayid(String playid) {
            this.playid = playid;
        }

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getAppid() {
            return appid;
        }

        public void setAppid(String appid) {
            this.appid = appid;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }
    }
}