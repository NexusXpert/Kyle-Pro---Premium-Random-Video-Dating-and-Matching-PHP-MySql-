package com.retrytech.strangerapp.utils.media;

public interface Packable {
    ByteBuf marshal(ByteBuf out);
}
